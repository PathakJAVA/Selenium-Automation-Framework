package com.Infor.Montefiore;
import java.io.IOException;
import java.util.Random;

import org.apache.commons.exec.ExecuteException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.Infor.Montefiore.TestData;
import com.prolifics.ProlificsSeleniumAPI;
public class ReceivableInvoice {
	
	ProlificsSeleniumAPI oPSelFW = null;
	TestData tdata;
	@Parameters({ "prjName", "testEnvironment","instanceName","sauceUser","moduleName","testSetName"})
	
	@BeforeClass
	public void oneTimeSetUp( String prjName,String testEnvironment,String instanceName,String sauceUser,String moduleName,String testSetName) throws InterruptedException, ExecuteException, IOException 
	{
	    String[] environment=new ProlificsSeleniumAPI().getEnvironment(testEnvironment,this.getClass().getName());	
		String os=environment[0];
	    String browser=environment[1];
	    String testCasename=this.getClass().getSimpleName();	
		oPSelFW = new ProlificsSeleniumAPI(prjName,testCasename,browser,os,instanceName,sauceUser,moduleName,testSetName);
		oPSelFW.sAutomationPath="C:\\Users\\svemireddy\\eclipse-workspace2\\montefiore\\";
		oPSelFW.startSelenium(oPSelFW.getURL("Home_URL_1",oPSelFW.instanceName));
		
		String filePath = System.getProperty("user.dir")+"\\Data\\Billingtocollections.xls";
		String sheet="Sheet1";		
		tdata = new TestData(filePath,sheet);
			
	}
	
	@Test
	public void bArchive() throws Exception
	{
		
		oPSelFW.prolifics("waitForElementPresent", "xpath=//a[@title='Montefiore Test Login']", "100");
		oPSelFW.prolifics("clickAndWait", "xpath=//a[@title='Montefiore Test Login']", "Click Montefiore Test Login");
		
		
		oPSelFW.prolifics("typeSpecifiedText", "xpath=//input[@type='email']", "tst_ARMgrMMC@montefioretest.org","Email to be entered");
		oPSelFW.prolifics("clickAndWait", "xpath=//input[@id='idSIButton9']", "Click Next");
		Thread.sleep(5000);
		oPSelFW.prolifics("typeSpecifiedText", "//input[@type='password']", "InforSit4TSTtA$$3476","Password");

		oPSelFW.prolifics("clickAndWait", "xpath=//input[@type='submit']", "Click Submit");
		
		oPSelFW.driver.findElement(By.xpath("//input[@id='idBtn_Back']")).click();
		Thread.sleep(5000);
		oPSelFW.prolifics("clickAndWait", "xpath=//button[@id='mhdrAppBtn']", "Click Menu");
		Thread.sleep(5000);
		oPSelFW.prolifics("clickAndWait", "xpath=//a[@id='icdeskSClk'][@title='Financials & Supply Management']", "Click Financials & Supply Management");;
		Thread.sleep(5000);
		
		oPSelFW.driver.switchTo().frame("fsm_10957de6-ce58-45c1-95b0-53e1818d3d37");
		
		Receivableinvoicemethods ri=new Receivableinvoicemethods();
		ri.ReceivableInvoice(oPSelFW,tdata);
		
	
	}
		@AfterClass
		public void closebrowser() throws Exception{
			try{
				oPSelFW.stopSelenium();
			}
			catch(Exception e){
					
			}
		}	
		
		
}
