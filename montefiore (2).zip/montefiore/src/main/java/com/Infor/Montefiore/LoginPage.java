package com.Infor.Montefiore;

import java.io.IOException;

import org.apache.commons.exec.ExecuteException;
import org.openqa.selenium.By;

import com.prolifics.ProlificsSeleniumAPI;

public class LoginPage {
	
	ProlificsSeleniumAPI oPSelFW = null;
	
	TestData tdata;
	
		
		public void Login_Page(ProlificsSeleniumAPI oPSelFW, TestData tdata) throws Exception {

		oPSelFW.prolifics("waitForElementPresent", "xpath=//a[@title='Montefiore Test Login']", "100");
		oPSelFW.prolifics("clickAndWait", "xpath=//a[@title='Montefiore Test Login']", "Click Montefiore Test Login");

		oPSelFW.prolifics("typeSpecifiedText", "xpath=//input[@type='email']", "tst_prjAdmnMMC@montefioretest.org",
				"Email to be entered");
		oPSelFW.prolifics("clickAndWait", "xpath=//input[@id='idSIButton9']", "Click Next");
		Thread.sleep(5000);
		oPSelFW.prolifics("typeSpecifiedText", "//input[@type='password']", "InforSit4TSTtA$$3656", "Password");

		oPSelFW.prolifics("clickAndWait", "xpath=//input[@type='submit']", "Click Submit");

		oPSelFW.driver.findElement(By.xpath("//input[@id='idBtn_Back']")).click();
		Thread.sleep(5000);
		oPSelFW.prolifics("clickAndWait", "xpath=//button[@id='mhdrAppBtn']", "Click Menu");
		Thread.sleep(5000);
		oPSelFW.prolifics("clickAndWait", "xpath=//a[@id='icdeskSClk'][@title='Financials & Supply Management']",
				"Click Financials & Supply Management");

		Thread.sleep(5000);

		oPSelFW.driver.switchTo().frame("fsm_10957de6-ce58-45c1-95b0-53e1818d3d37");
}
}