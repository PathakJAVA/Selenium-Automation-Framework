package com.Infor.Montefiore;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.apache.poi.ss.usermodel.DateUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.Infor.Montefiore.TestData;
import com.prolifics.ProlificsSeleniumAPI;

/*##################################################################################################
     # Method:Invoice Batch Creation To Release
     # Author:
     # Date:
     # Last Edited:
     # Description :Creation of InvoiceBatch,TransactionItems , Distributions and To Release the batch
    ######################################################################################################*/


public class Receivableinvoicemethods{

	public static String ReceivablesManager = "xpath=//div[@class='lm-card-title has-tooltip']/a/span[(text()='Receivables Manager')]";
	public static String Menu = "//button[@id='app-menu-trigger']";
	public static String Processing = "xpath=//div[@id='appmenu_ReceivablesManagerMenu_prd_Processing']";
	public static String Invoices = "xpath=//span[normalize-space()='Invoices']";
	public static String Create = "//button[@id='ReceivableInvoicesPage_InvoiceBatches_0_ReceivableInvoiceBatchList_Create_1']";
	public static String CCode = "//input[@id='ReceivableInvoiceBatchForm_Company']";
	public static String PLevel = "//input[@id='ReceivableInvoiceBatchForm_ReceivableProcessLevel']";
	public static String PostDate = "//input[@bindid='GeneralLedgerDate']";
	public static String CTotal = "//input[@id='ReceivableInvoiceBatchForm_CountTotal_1']";
	public static String IAmt = "//input[@bindid='InvoiceTotal']";
	public static String Save = "//button[@id='ReceivableInvoiceBatchForm_StandardSave']";
	public static String Trans = "//a[@data-automation-id='lm-ReceivableInvoiceBatchForm-Transaction-tab']";
	public static String TCreate = "//button[@id='ReceivableInvoiceBatchForm_Transaction_3_ListReceivableInvoice_StandardCreate']";
	public static String RCustomer = "//input[@bindid='Customer']";
	public static String Type = "//div[@class='dropdown dropdown-mm']";
	public static String TInv = "//a[@id='list-option-3']";
	public static String TTrans = "//input[@bindid='ReceivableInvoice']";
	public static String TAmt = "//input[@bindid='TransientSignedTransactionAmount']";
	public static String TSave = "//button[@id='SelectionOptions_StandardSave']";
	public static String Lineitems = "//li/a[(text()='Line Items')]";
	public static String LCreate = "//button[@id='SelectionOptions_LineItems_4_ListReceivableInvoiceLineItem_StandardCreate']";
	public static String Checkbox = "//span[@class='datagrid-checkbox']/../../../..//following-sibling::tbody/tr/td[1]";
	public static String Des = "//td[contains(@aria-describedby,'SelectionOptions_LineItems_4_ListReceivableInvoiceLineItem_datagrid-1-header-1')]";
	public static String LAmt = "//span[text()='Transaction Amount']/../../../..//following-sibling::tbody/tr/td[8]";
	public static String Distributions = "//li/a[(text()='Distributions')]";
	public static String DCreate = "//button[@id='SelectionOptions_Distributions_5_ReceivableInvoiceDistributionList_StandardCreate']";
	public static String DC = "//span[text()='Distribution Category']/../../../..//following-sibling::tbody/tr/td[2]";
	public static String CAmt = "//td[contains(@aria-describedby,'SelectionOptions_Distributions_5_ReceivableInvoiceDistributionList_datagrid-2-header-2')]";
	public static String GLAC = "//span[text()='Global Ledger Account']/../../../..//following-sibling::tbody/tr/td[4]";
	public static String Idex = "//div[@class='has-tooltip ng-star-inserted']/span/input[@bindid='GeneralLedgerAccount_prd_FinanceDimension5']";
	public static String AC = "//div[@class='has-tooltip ng-star-inserted']/span/input[@bindid='GeneralLedgerAccount_prd_GeneralLedgerChartAccount']";
	public static String OK = "//button[@id='ReceivableInvoiceDistributionList_ReceivableInvoiceDistributionList_Ok']";
    public static String Invno = "//input[@id='ReceivableInvoicesPage-ReceivableInvoicesPage_InvoiceBatches_0_ReceivableInvoiceBatchList_datagrid-1-header-filter-2']";
	public static String Click = "//span[normalize-space()='Status']/../../../..//following-sibling::tbody/tr/td[3]";
	public static String open = "//button[@id='ReceivableInvoicesPage_InvoiceBatches_0_ReceivableInvoiceBatchList_StandardOpen']";
	public static String Release = "//button[@id='ReceivableInvoiceBatchForm_ReleaseUnreleased_0']";
	public static String Icon = "//button[@id='rNavUsrBtn']";
	public static String SignOut = "//div[@id='rNavUsrMnu']//span[@id='usrOutTxt']";
	
	
	public void ReceivableInvoice(ProlificsSeleniumAPI oPSelFW, TestData tdata) throws Exception {
	
		String tno = "INV"+new SimpleDateFormat("mmss").format(new Date());
		oPSelFW.prolifics("waitForElementPresent", ReceivablesManager, "10");
		oPSelFW.prolifics("clickAndWait", ReceivablesManager, "Click Receivables Manager");
		
		oPSelFW.prolifics("clickAndWait", Menu, "Click Menu");
		Thread.sleep(3000);
		oPSelFW.prolifics("waitForElementPresent", Processing, "100");
		oPSelFW.prolifics("clickAndWait", Processing, "Click Processing");
		oPSelFW.prolifics("waitForElementPresent", Invoices, "100");
		oPSelFW.prolifics("clickAndWait", Invoices, "Click Invoices");
		oPSelFW.prolifics("waitForElementPresent", Create, "100");
		oPSelFW.prolifics("clickAndWait", Create, "Click Create");
		oPSelFW.prolifics("waitForElementPresent", CCode, "100");
		oPSelFW.prolifics("typeSpecifiedText", CCode, tdata.getCellData("CompanyCode", 2), "Company");
		oPSelFW.prolifics("typeSpecifiedText", PLevel, tdata.getCellData("ProcessLevel", 2), "ProcessLevel");
		String PDateFromExcel = tdata.getCellData("PostDate", 2);
		java.util.Date javaDate = DateUtil.getJavaDate(Double.parseDouble(PDateFromExcel));
		String PDate = new SimpleDateFormat("MM/dd/yyyy").format(javaDate);
		oPSelFW.prolifics("clickAndWait", PostDate, "100");
		oPSelFW.prolifics("typeSpecifiedText", PostDate, PDate, "Date Selected");
		oPSelFW.prolifics("typeSpecifiedText", CTotal, tdata.getCellData("Count", 2), "Count of Invoices");
		oPSelFW.prolifics("typeSpecifiedText", IAmt, tdata.getCellData("Amount", 2), "Invoice Amount");
		oPSelFW.prolifics("waitForElementPresent", Save, "100");
		oPSelFW.prolifics("clickAndWait", Save, "Click Save");
		Thread.sleep(4000);
    	String invoicebatchno =oPSelFW.driver.findElement(By.xpath("//p[@id='ReceivableInvoiceBatchForm_ReceivableInvoiceBatch']")).getText();

		String tstatus = oPSelFW.driver.findElement(By.xpath("//span[@class='toast-message']")).getText();

		oPSelFW.prolifics("captureEntirePageScreenshot", "Verify Alert","Actual Alert : " + tstatus + " Expected Alert : " + tstatus, "Pass");
		oPSelFW.prolifics("waitForElementPresent", Trans, "100");
		oPSelFW.prolifics("clickAndWait", Trans, "Click Transaction ");
		oPSelFW.prolifics("waitForElementPresent", TCreate, "100");
		oPSelFW.prolifics("clickAndWait", TCreate, "Click Create ");
		oPSelFW.prolifics("typeSpecifiedText", RCustomer, tdata.getCellData("Customer", 2), "Customer");
		oPSelFW.prolifics("waitForElementPresent", Type, "100");
		oPSelFW.prolifics("clickAndWait", Type, "Click Type");
		oPSelFW.prolifics("waitForElementPresent", TInv, "100");
		oPSelFW.prolifics("clickAndWait", TInv, "Click Invoice");
		oPSelFW.prolifics("typeSpecifiedText", TTrans, tno, "Transaction");
		oPSelFW.prolifics("typeSpecifiedText", TAmt, tdata.getCellData("Amount", 2), "Amount");
		Thread.sleep(4000);
		oPSelFW.prolifics("waitForElementPresent", TSave, "100");
		oPSelFW.prolifics("clickAndWait", TSave, "Click Save");
		Thread.sleep(4000);
		String tstatus1 = oPSelFW.driver.findElement(By.xpath("//span[@class='toast-message']")).getText();
		oPSelFW.prolifics("captureEntirePageScreenshot", "Verify Alert","Actual Alert : " + tstatus1 + " Expected Alert : " + tstatus1, "Pass");
		oPSelFW.prolifics("waitForElementPresent", Lineitems, "10");
		oPSelFW.prolifics("clickAndWait", Lineitems, "Click Line Items");
		oPSelFW.prolifics("waitForElementPresent", LCreate, "100");
		oPSelFW.prolifics("clickAndWait", LCreate, "Click Create ");
		Thread.sleep(2000);
		oPSelFW.prolifics("clickAndWait", Des, "Description");
		Thread.sleep(3000);
		oPSelFW.prolifics("typeSpecifiedText", "//div[@class='datagrid-cell-wrapper']/input",tdata.getCellData("Description", 2), "Description");
		Thread.sleep(2000);
		oPSelFW.prolifics("clickAndWait", LAmt, "100");
		oPSelFW.driver.findElement(By.xpath("//span[text()='Transaction Amount']/../../../..//following-sibling::tbody/tr/td[8]")).sendKeys(Keys.BACK_SPACE);
		Thread.sleep(1000);
		oPSelFW.prolifics("typeSpecifiedText", "//div[@class='datagrid-cell-wrapper']/input",tdata.getCellData("Amount", 2), "TransactionAmount");
		oPSelFW.prolifics("waitForElementPresent", TSave, "100");
		oPSelFW.prolifics("clickAndWait", TSave, "Click Save");
		Thread.sleep(4000);
		String tstatus2 = oPSelFW.driver.findElement(By.xpath("//span[@class='toast-message']")).getText();
		oPSelFW.prolifics("captureEntirePageScreenshot", "Verify Alert","Actual Alert : " + tstatus2 + " Expected Alert : " + tstatus2, "Pass");
		oPSelFW.prolifics("waitForElementPresent", Distributions, "10");
		oPSelFW.prolifics("clickAndWait", Distributions, "Click Distributions");
		oPSelFW.prolifics("waitForElementPresent", DCreate, "100");
		oPSelFW.prolifics("clickAndWait", DCreate, "Click Create ");
		Thread.sleep(2000);
		oPSelFW.prolifics("clickAndWait", CAmt, "10");
		oPSelFW.driver.findElement(By.xpath("//td[contains(@aria-describedby,'SelectionOptions_Distributions_5_ReceivableInvoiceDistributionList_datagrid-2-header-2')]")).sendKeys(Keys.BACK_SPACE);
		Thread.sleep(1000);
		System.out.println("print" + tdata.getCellData("Amount", 2));
		oPSelFW.prolifics("typeSpecifiedText", "//div[@class='datagrid-cell-wrapper']/input",tdata.getCellData("Amount", 2), "CurrencyAmount");
		oPSelFW.prolifics("clickAndWait", DC, "100");
		Thread.sleep(1000);
		oPSelFW.prolifics("typeSpecifiedText", "//div[@class='datagrid-cell-wrapper']/span/input",tdata.getCellData("Dcategory", 2), "DistributionCategory");
		oPSelFW.prolifics("clickAndWait", GLAC, "100");
		oPSelFW.prolifics("typeSpecifiedText", Idex, tdata.getCellData("Index", 2), "INDEX");
		oPSelFW.prolifics("typeSpecifiedText", AC, tdata.getCellData("Account", 2), "ACCOUNT");
		oPSelFW.prolifics("waitForElementPresent", OK, "100");
		oPSelFW.prolifics("clickAndWait", OK, "Click Ok");
		oPSelFW.prolifics("waitForElementPresent", TSave, "100");
		oPSelFW.prolifics("clickAndWait", TSave, "Click Save");
		Thread.sleep(4000);
		String tstatus3 = oPSelFW.driver.findElement(By.xpath("//span[@class='toast-message']")).getText();
		oPSelFW.prolifics("captureEntirePageScreenshot", "Verify Alert","Actual Alert : " + tstatus3 + " Expected Alert : " + tstatus3, "Pass");
		Thread.sleep(2000);
		oPSelFW.driver.navigate().back();
		Thread.sleep(15000);
		oPSelFW.driver.navigate().back();
		Thread.sleep(5000);
		
		oPSelFW.driver.switchTo().frame("fsm_10957de6-ce58-45c1-95b0-53e1818d3d37");
		oPSelFW.prolifics("typeSpecifiedText", Invno,invoicebatchno ,"InvoiceBatchNumber");
		oPSelFW.driver.findElement(By.xpath("//input[@id='ReceivableInvoicesPage-ReceivableInvoicesPage_InvoiceBatches_0_ReceivableInvoiceBatchList_datagrid-1-header-filter-2']")).sendKeys(Keys.ENTER);
		
		Thread.sleep(3000);
        String Statusunreleased =oPSelFW.driver.findElement(By.xpath("//span[normalize-space()='Status']/../../../..//following-sibling::tbody/tr/td[8]")).getText();
		
		oPSelFW.prolifics("captureEntirePageScreenshot", "Verify Status", "Actual Status : "+Statusunreleased +" Expected Status : "+Statusunreleased, "Pass");
		oPSelFW.prolifics("waitForElementPresent", Click, "10");
		oPSelFW.prolifics("clickAndWait", Click, "ClickInvoiceBatchNumber ");
		
		oPSelFW.prolifics("clickAndWait", open, "Click Open");
		oPSelFW.driver.switchTo().defaultContent();
		oPSelFW.driver.switchTo().frame("fsm_10957de6-ce58-45c1-95b0-53e1818d3d37");
		oPSelFW.prolifics("waitForElementPresent", Release, "10");
		oPSelFW.prolifics("clickAndWait", Release, "Click Release");
		Thread.sleep(4000);
		String tstatus4 = oPSelFW.driver.findElement(By.xpath("//span[@class='toast-message']")).getText();
		oPSelFW.prolifics("captureEntirePageScreenshot", "Verify Alert","Actual Alert : " + tstatus4 + " Expected Alert : " + tstatus4, "Pass");
		oPSelFW.driver.navigate().back();
		Thread.sleep(7000);
		oPSelFW.prolifics("clickAndWait", Icon, "Click User Icon");
		Thread.sleep(7000);
		oPSelFW.prolifics("waitForElementPresent", SignOut, "100");
		oPSelFW.prolifics("clickAndWait", SignOut, "Click Sign Out");
		
	}
}
