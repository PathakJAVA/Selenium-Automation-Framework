/*package com.Mckesson.Digital_Marketing;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class ExcelReader
{
private final List<Map<String, String>> data;
private List<String> columns;

public ExcelReader(String filePath, String spreadsheetName)
throws IOException
{
data = read(Res.get(filePath), spreadsheetName);
}

public Object[][] convertedData() {
Object[][] convert = new Object[data.size()][columns.size()];
for (int i = 0; i < data.size(); i++) {
Object[] item = new Object[columns.size()];
Map<String, String> subList = (Map)data.get(i);
for (int j = 0; j < columns.size(); j++) {
item[j] = subList.get(columns.get(j));
}
convert[i] = item;
}

return convert;
}

private List<Map<String, String>> read(URL SheetUrl, String sheetName) throws IOException {
List<Map<String, String>> contents = new ArrayList();

HSSFWorkbook workbook = new HSSFWorkbook(SheetUrl.openStream());
HSSFSheet sheet = workbook.getSheet(sheetName);
Iterator<Row> rows = sheet.iterator();
columns = new ArrayList();

boolean firstrow = true;

while (rows.hasNext()) {
Row row = (Row)rows.next();
Iterator<Cell> cells = row.cellIterator();
if (firstrow) {
while (cells.hasNext()) {
Cell cell = (Cell)cells.next();
columns.add(cell.getStringCellValue());
}
firstrow = false;
}
else {
Map<String, String> rowData = new HashMap();
while (cells.hasNext()) {
Cell cell = (Cell)cells.next();
rowData.put((String)columns.get(cell.getColumnIndex()), cell.toString());
}
contents.add(rowData);
}
}



return contents;
}
}*/