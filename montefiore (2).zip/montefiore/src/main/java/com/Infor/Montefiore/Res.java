package com.Infor.Montefiore;


import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.io.FileUtils;




public class Res
{
private static final File[] parents = { new File("."), 
new File("./src/main/resources"), 
new File("./src/test/resources") };





public Res() {}




public static URL get(String name)
{
URL res = Thread.currentThread().getContextClassLoader()
.getResource(name);
if (res == null) {
File resFile = new File("res", name);
if (!resFile.exists()) {
resFile = new File(name);
}
try {
res = resFile.getCanonicalFile().toURI().toURL();
} catch (MalformedURLException e) {
System.out.println("Could not transform \"" + name + 
"\" into a URL");
e.printStackTrace();
} catch (IOException e) {
System.out.println("Unable to retrieve the canonical path for \"" + name + 
"\"");
e.printStackTrace();
}
}

return res;
}











public static File getFile(String name)
throws IOException
{
for (File parent : parents) {
File res = new File(parent, name).getCanonicalFile();
if (res.isFile()) {
return res;
}
}
URL resUrl = Thread.currentThread().getContextClassLoader().getResource(name);

if (resUrl != null) {
String filename = getFileFriendlyName(name);
int extIndex = filename.lastIndexOf(".");
String prefix = filename;
String ext = "";

if (extIndex >= 1) {
ext = filename.substring(extIndex);
prefix = filename.substring(0, extIndex);
}
File res = File.createTempFile(prefix, ext);
FileUtils.copyURLToFile(resUrl, res);
return res;
}

throw new IOException("Unable to locate resource: " + name);
}







private static String getFileFriendlyName(String resourceName)
{
File res = new File(resourceName);

return res.getName();
}
}