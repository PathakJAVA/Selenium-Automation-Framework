package com.Infor.Montefiore;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.prolifics.ProlificsSeleniumAPI;


public class Pom {

	// Constants
	File file;
	Properties prop = new Properties();
	public FileInputStream fileInput;
	ProlificsSeleniumAPI oPSelFW;

	public Pom( ProlificsSeleniumAPI oPSelFW){

		this.oPSelFW=oPSelFW;
		file=new File(oPSelFW.sAutomationPath+File.separator+oPSelFW.sProjectName+File.separator+"Constants"+File.separator+"PatelCo_NativeAppConstant.properties");
	}


	public void PageTitle(String title) throws Exception{

		oPSelFW.driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(5000);
		String pageTitle =  oPSelFW.prolifics("getTitle");

		if(pageTitle.trim().equalsIgnoreCase(title.trim())){
			System.out.println("Pass------"+pageTitle);
			oPSelFW.prolifics("sendReport", "Verify Home Page Title", "Actual Page Title : "+ pageTitle +" Expected Page Title : "+title, "Pass");
		}
		else{
			System.out.println("Fail------"+pageTitle);
			oPSelFW.prolifics("sendReportWithOutExit", "Verify Home Page Title", "Actual Page Title : "+ pageTitle +" Expected Page Title : "+title, "Fail");
		}
	}

	public void logo(String expectedLogo, String url, String title) throws Exception{

		oPSelFW.prolifics("waitForElementPresent", "xpath=//*[@class='navbar-header']/a", "100");
		oPSelFW.prolifics("clickAndWait", "xpath=//*[@class='navbar-header']/a", "Click McKesson Logo");
		Thread.sleep(2000);
		PageTitle(title);

		String logo = oPSelFW.prolifics("getText", "xpath=//*[@class='navbar-header']/a", "Logo");

		if(logo.equalsIgnoreCase(expectedLogo)){
			System.out.println("Pass------"+logo);
			oPSelFW.prolifics("sendReport", "Validate McKesson Logo is displayed", "McKesson Logo is displayed successfully", "Pass");
		}
		else{
			System.out.println("Fail------"+logo);
			oPSelFW.prolifics("sendReportWithOutExit", "Validate McKesson Logo is displayed", "McKesson Logo is not displayed", "Fail");
		}
		oPSelFW.driver.navigate().to(url);
		oPSelFW.driver.navigate().refresh();

	}

	public void searchKey(String search, String url) throws InterruptedException{
		System.out.println(url);
		oPSelFW.prolifics("clickAndWait", "xpath=//*[@id='search-field']");
		oPSelFW.prolifics("typeSpecifiedText", "xpath=//*[@id='search-field']", "McKesson","searchkey");
		oPSelFW.driver.findElement(By.xpath("//*[@id='search-field']")).sendKeys(search);
		Thread.sleep(7000);
	/*	WebElement createsearch1 = oPSelFW.driver.findElement(By.xpath("//*[@class='sayt-list']"));

		String text = createsearch1.getText();
		System.out.println("Text value: " + text); 
		if (text.contains("mckesson")){System.out.print("Yes");}else{System.out.print("No");}*/
		oPSelFW.prolifics("clickAndWait", "//button[text()='Search']");
		//oPSelFW.prolifics("verifyText", "xpath=//*[@class='search-term']",search);
		oPSelFW.driver.navigate().to(url);
	}
		
	public void headerLink(String systemType, String link, String sublink, String pageTitle, String url) throws InterruptedException{

		String title = null;
		if(systemType.equalsIgnoreCase("MOBILE")){

			if(link.equalsIgnoreCase("Providers")||link.equalsIgnoreCase("Pharmacies")||link.equalsIgnoreCase("Manufacturers")||link.equalsIgnoreCase("Health Plans")){
				oPSelFW.prolifics("waitForElementPresent", "//span[contains(text(),'Solutions')]", "150");
				oPSelFW.prolifics("clickAndWait", "//span[contains(text(),'Solutions')]", "Click Solutions");
				System.out.println("clicked solutions");
				oPSelFW.prolifics("waitForElementPresent", "//strong[contains(text(),'"+link+"')]", "100");
				oPSelFW.prolifics("clickAndWait", "//strong[contains(text(),'"+link+"')]", "Click "+link);

				oPSelFW.prolifics("waitForElementPresent", "//strong[contains(text(),'"+link+"')]/../following-sibling::div//a[text()='"+sublink+"']", "100");
				oPSelFW.prolifics("clickAndWait", "//strong[contains(text(),'"+link+"')]/../following-sibling::div//a[text()='"+sublink+"']", "Click "+sublink);

				Thread.sleep(5000);
				title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
			}
			if(link.equalsIgnoreCase("All Solutions")){

				oPSelFW.prolifics("waitForElementPresent", "//span[contains(text(),'Solutions')]", "100");
				oPSelFW.prolifics("clickAndWait", "//span[contains(text(),'Solutions')]", "Click Solutions");

				oPSelFW.prolifics("waitForElementPresent", "//div[@id='browse-tab0']//a[text()='All Solutions']", "100");
				oPSelFW.prolifics("clickAndWait", "//div[@id='browse-tab0']//a[text()='All Solutions']", "Click All Solutions");
				Thread.sleep(5000);
				title = oPSelFW.driver.findElement(By.xpath("//h1[@id='ctl00_ctl00_ContentPlaceHolder1_ContentMain_headerTitle']")).getText();
			}
			if(link.equalsIgnoreCase("Careers")||link.equalsIgnoreCase("Investors")||link.trim().equalsIgnoreCase("Contact Us")||link.trim().equalsIgnoreCase("Customer Login")){

				oPSelFW.prolifics("waitForElementPresent", "//span[text()='More >']", "100");
				oPSelFW.prolifics("clickAndWait", "//span[text()='More >']", "Click More");
				System.out.println("Clicked more");
				Thread.sleep(2000);
				oPSelFW.prolifics("waitForElementPresent", "//nav[@class='st-menu st-effect-3']//a[text()='"+link+"']", "100");
				oPSelFW.prolifics("clickAndWait", "//nav[@class='st-menu st-effect-3']//a[text()='"+link+"']", "Click "+link);
				Thread.sleep(5000);
				title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
			}
		}
		else if(systemType.equalsIgnoreCase("DESKTOP")){
			System.out.println("ENtered into desktop view ");
			//  05/11/2018 if(link.equalsIgnoreCase("Providers")||link.equalsIgnoreCase("Pharmacies")||link.equalsIgnoreCase("Biopharma")||link.equalsIgnoreCase("Health Plans")){
				
			if(link.equalsIgnoreCase("Pharmaceutical Distribution")||link.equalsIgnoreCase("Wholesale Medical Supplies")||link.equalsIgnoreCase("Pharmacy Services & Technology")||link.equalsIgnoreCase("Solutions for Specialty Practices")||link.equalsIgnoreCase("Solutions for Biopharma")||link.equalsIgnoreCase("GCP McKStaging for Biopharma")||link.equalsIgnoreCase("GCP McKStaging for Biopharma")){
				
			
				oPSelFW.prolifics("waitForElementPresent", "//span[contains(text(),'"+link+"')]", "100");
				oPSelFW.prolifics("clickAndWait", "//span[contains(text(),'"+link+"')]", "Click "+link);

				oPSelFW.prolifics("waitForElementPresent", "//span[contains(text(),'"+link+"')]/../following-sibling::div//a[text()='"+sublink+"']", "100");
				oPSelFW.prolifics("clickAndWait", "//span[contains(text(),'"+link+"')]/../following-sibling::div//a[text()='"+sublink+"']", "Click "+sublink);

				Thread.sleep(5000);
				title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
				System.out.println("title" +title);
			}

			if(link.equalsIgnoreCase("All Solutions")){

				oPSelFW.prolifics("waitForElementPresent", "//div[@class='link-tab all']//a[text()='All Solutions']", "100");
				oPSelFW.prolifics("clickAndWait", "//div[@class='link-tab all']//a[text()='All Solutions']", "Click All Solutions");
				Thread.sleep(5000);
				title = oPSelFW.driver.findElement(By.xpath("//h1[@id='ctl00_ctl00_ContentPlaceHolder1_ContentMain_headerTitle']")).getText();

			}
			if(link.equalsIgnoreCase("About Us")||link.equalsIgnoreCase("Careers")||link.equalsIgnoreCase("Investors")||link.trim().equalsIgnoreCase("Contact Us")||link.trim().equalsIgnoreCase("Logins")){

				oPSelFW.prolifics("waitForElementPresent", "//div[@id='navbar']//a[text()='"+link+"']", "100");
				oPSelFW.prolifics("clickAndWait", "//div[@id='navbar']//a[text()='"+link+"']", "Click "+link);
				Thread.sleep(5000);
				title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
			}
		}

		if(link.equalsIgnoreCase("Blog")){

			oPSelFW.prolifics("waitForElementPresent", "//div[@id='navbar']//a[text()='"+link+"']", "100");
			oPSelFW.prolifics("clickAndWait", "//div[@id='navbar']//a[text()='"+link+"']", "Click "+link);
			Thread.sleep(5000);
			
			title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
		}
	

		//title	= oPSelFW.driver.getTitle();
		System.out.println("Ttitle "+title+"/");
		System.out.println("Ptitle "+pageTitle+"/");

		if(title.trim().equalsIgnoreCase(pageTitle.trim())){
			System.out.println("Pass header title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

		}
		else{
			System.out.println("Fail header title "+title);
			//oPSelFW.prolifics("sendReportWithOutExit", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
			oPSelFW.prolifics("sendReportWithOutExit", "**Title Verification Mismatch.. Ignoring the mismatch***", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Ignore");
			

		}
		oPSelFW.driver.navigate().to(url);
		oPSelFW.driver.navigate().refresh();

		Thread.sleep(3000);
	}


	public void footerLink(String sysType, String mainLink, String linkText, String pageTitle, String url) throws InterruptedException{

		
		if(sysType.equalsIgnoreCase("Mobile")){

			if(linkText.equalsIgnoreCase("About McKesson")||linkText.equalsIgnoreCase("Blog")||linkText.equalsIgnoreCase("Careers")||linkText.equalsIgnoreCase("Popular Products")||linkText.equalsIgnoreCase("Resources")||linkText.equalsIgnoreCase("Customer Ordering")||linkText.equalsIgnoreCase("Investors")||linkText.equalsIgnoreCase("Our Businesses")||linkText.equalsIgnoreCase("McKesson International")||linkText.equalsIgnoreCase("McKesson Ventures")){

				oPSelFW.prolifics("waitForElementPresent", "//*[@class='footer-nav four-columns']//a[contains(text(),'"+linkText+"')]", "100");
				oPSelFW.prolifics("clickAndWait", "//*[@class='footer-nav four-columns']//a[contains(text(),'"+linkText+"')]", "Click "+linkText);
				oPSelFW.prolifics("sendReport", "Click "+linkText, "Successfully clicked "+linkText, "Pass");
				Thread.sleep(10000);
			}
			else{
				Thread.sleep(5000);
				oPSelFW.prolifics("waitForElementPresent", "//*[@class='footer-nav four-columns']//a[contains(text(),'"+mainLink+"')]/ancestor::li", "100");
				oPSelFW.prolifics("clickAndWait", "//*[@class='footer-nav four-columns']//a[contains(text(),'"+mainLink+"')]/ancestor::li", "Click "+mainLink);
				System.out.println("click "+mainLink+" and then "+linkText);
				Thread.sleep(5000);
				oPSelFW.prolifics("waitForElementPresent", "//a[text()='"+mainLink+"']/ancestor::li/following-sibling::li//a[contains(text(),'"+linkText+"')]", "100");
				oPSelFW.prolifics("clickAndWait", "//a[text()='"+mainLink+"']/ancestor::li/following-sibling::li//a[contains(text(),'"+linkText+"')]", "Click "+linkText);
				Thread.sleep(10000);
			}
		}

		if(sysType.equalsIgnoreCase("Desktop")){

			if(linkText.equalsIgnoreCase("Solutions for Drug")){
				System.out.println("in drug");
				oPSelFW.prolifics("waitForElementPresent", "//*[@class='footer-nav four-columns']//a[contains(text(),'Solutions for Drug')]", "100");
				oPSelFW.prolifics("clickAndWait", "//*[@class='footer-nav four-columns']//a[contains(text(),'Solutions for Drug')]", "Click "+linkText);
				System.out.println("linkText"+linkText);
				oPSelFW.prolifics("sendReport", "Click "+linkText, "Successfully clicked", "Pass");
				Thread.sleep(20000);
			}
			else{
				oPSelFW.prolifics("waitForElementPresent", "//*[@class='footer-nav four-columns']//a[text()='"+linkText+"']", "100");
				oPSelFW.prolifics("clickAndWait", "//*[@class='footer-nav four-columns']//a[text()='"+linkText+"']", "Click "+linkText);
				//linkText="Fournitures médicales, produits pharmaceutiques et services de santé | McKesson Canada - McKesson Canada Extranet - Mckesson Canada";
				System.out.println("linkText"+linkText);
				oPSelFW.prolifics("sendReport", "Click "+linkText, "Successfully clicked", "Pass");
				Thread.sleep(20000); 
			}
		}

		Thread.sleep(2000);
		String title =  oPSelFW.prolifics("getTitle");
		//title	= removeSpecialCharacter(title);
		System.out.println("title== "+title);

		if(title.trim().equalsIgnoreCase(pageTitle.trim())){
			System.out.println("Pass footer title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title+", Expected page title : "+pageTitle, "Pass");

		}
		else{
			System.out.println("Fail footer title "+title);
			//oPSelFW.prolifics("sendReportWithOutExit", "Verify Title", "Actual Page Title : "+title+", Expected page title : "+pageTitle, "Fail");
			oPSelFW.prolifics("sendReportWithOutExit", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Ignore");
		}

		oPSelFW.driver.navigate().to(url);
		oPSelFW.driver.navigate().refresh();

	}

	public void discFooter(String link,String pageTitle, String url) throws InterruptedException{

		oPSelFW.prolifics("waitForElementPresent", "//*[@class='footer-disc']//a[text()='"+link+"']", "100");


		JavascriptExecutor js = ((JavascriptExecutor) oPSelFW.driver);
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");

		System.out.println("scrolled to bottom");
		Thread.sleep(7000);

		oPSelFW.prolifics("clickAndWait", "//*[@class='footer-disc']//a[text()='"+link+"']", "Click "+link);
		oPSelFW.prolifics("sendReport", "Click "+link, "Successfully clicked "+link, "Pass");
		System.out.println("clicked "+link);
		Thread.sleep(7000);

		String title = oPSelFW.driver.getTitle();/*.findElement(By.xpath("//h1[@class='title']")).getText();*/
		if(title.trim().equalsIgnoreCase(pageTitle.trim())){
			System.out.println("Pass disc footer title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

		}
		else{
			System.out.println("Fail disc footer title "+title);
			//oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
			oPSelFW.prolifics("sendReportWithOutExit", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Ignore");
			
		
		}
		oPSelFW.driver.navigate().to(url);
		oPSelFW.driver.navigate().refresh();
		Thread.sleep(5000);
	}



	public void lnavigation(String link,String pageTitle, String url) throws InterruptedException{

		oPSelFW.prolifics("waitForElementPresent", "//span[text()='"+link+"']", "100");
		oPSelFW.prolifics("clickAndWait", "//span[text()='"+link+"']", "Click "+link);
		oPSelFW.prolifics("sendReport", "Click "+link, "Successfully clicked "+link, "Pass");
		Thread.sleep(5000);

		String title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
		if(title.trim().equalsIgnoreCase(pageTitle)){
			System.out.println("Pass Link title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

		}
		else{
			System.out.println("Fail Link title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
		}
		oPSelFW.driver.navigate().to(url);
		oPSelFW.driver.navigate().refresh();
		Thread.sleep(5000);
	}
	public void whoWeAre(String link,String pageTitle, String url) throws InterruptedException{

		oPSelFW.prolifics("waitForElementPresent", "//span[text()='"+link+"']", "100");
		oPSelFW.prolifics("clickAndWait", "//span[text()='"+link+"']", "Click "+link);
		oPSelFW.prolifics("sendReport", "Click "+link, "Successfully clicked "+link, "Pass");
		Thread.sleep(5000);

		String title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
		if(title.trim().equalsIgnoreCase(pageTitle.trim())){
			System.out.println("Pass Link title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

		}
		else{
			System.out.println("Fail Link title "+title);
			oPSelFW.prolifics("sendReportWithOutExit", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
		}
		oPSelFW.driver.navigate().to(url);
		oPSelFW.driver.navigate().refresh();
		Thread.sleep(5000);
	}

	public void ourBusinessLinkHeader(String link,String pageTitle, String url) throws InterruptedException{
		if(link.equalsIgnoreCase("branded")||link.equalsIgnoreCase("generic")||link.equalsIgnoreCase("over-the-counter")
				||link.equalsIgnoreCase("long-term care providers")||link.equalsIgnoreCase("home care agencies")
				||link.equalsIgnoreCase("long-term care facilities")||link.equalsIgnoreCase("surgery centers")||link.equalsIgnoreCase("Macro Helix")
				||link.equalsIgnoreCase("McKesson High Volume Solutions")||link.equalsIgnoreCase("McKesson Pharmacy Systems")
				||link.equalsIgnoreCase("Supplylogix")||link.equalsIgnoreCase("Executive Officers")
				||link.equalsIgnoreCase("Board of Directors")){
			System.out.println("Pass footer title "+link);
			oPSelFW.prolifics("waitForElementPresent", "//*[@title='"+link+"']", "100");
			oPSelFW.prolifics("clickAndWait", "//*[@title='"+link+"']", "Click "+link);
			oPSelFW.prolifics("sendReport", "Click "+link, "Successfully clicked "+link, "Pass");
			Thread.sleep(5000);

			String title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
			if(title.trim().equalsIgnoreCase(pageTitle.trim())){
				System.out.println("Pass Link title "+title);
				oPSelFW.prolifics("sendReportWithOutExit", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

			}
			else{
				System.out.println("Fail Link title "+title);
				oPSelFW.prolifics("sendReportWithOutExit", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
			}
			oPSelFW.driver.navigate().to(url);
			oPSelFW.driver.navigate().refresh();
			Thread.sleep(5000);
		}else{
			oPSelFW.prolifics("waitForElementPresent", "//h3[text()='"+link+"']", "100");
			oPSelFW.prolifics("clickAndWait", "//h3[text()='"+link+"']", "Click "+link);
			oPSelFW.prolifics("sendReportWithOutExit", "Click "+link, "Successfully clicked "+link, "Pass");
			Thread.sleep(5000);

			String title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
			if(title.trim().equalsIgnoreCase(pageTitle.trim())){
				System.out.println("Pass Link title "+title);
				oPSelFW.prolifics("sendReportWithOutExit", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

			}
			else{
				System.out.println("Fail Link title "+title);
				oPSelFW.prolifics("sendReportWithOutExit", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
			}
			oPSelFW.driver.navigate().to(url);
			oPSelFW.driver.navigate().refresh();
			Thread.sleep(5000);
		}}

	public void ourBusinessLinkHeaderTitle(String url) throws InterruptedException{

		oPSelFW.prolifics("clickAndWait", "//span[text()='McKesson Corporate Profile (PDF, 2 MB)']", "Click McKesson Corporate Profile (PDF, 1.8 MB)");
		oPSelFW.prolifics("clickAndWait", "//*[@title='McKesson Corporation<br />Overview']", "Click McKesson Corporation Overview");

		String pageTitle="Go to McKesson Canada Extranet";
		String pageTitle1 ="McKesson Europe Home";
		ArrayList<String> al=new ArrayList<String>();  
		al.add("McKesson Canada");  
		al.add("McKesson Europe");  

		for(String link:al)  {
			if (link.equals("McKesson Canada")){
				oPSelFW.prolifics("waitForElementPresent", "//h3[text()='"+link+"']", "100");
				oPSelFW.prolifics("clickAndWait", "//h3[text()='"+link+"']", "Click "+link);
				oPSelFW.prolifics("sendReport", "Click "+link, "Successfully clicked "+link, "Pass");
				Thread.sleep(5000);

				WebElement element=   oPSelFW.driver.findElement(By.xpath("//*[@title='Go to McKesson Canada Extranet']"));
				String title = element.getAttribute("title");
				System.out.println("Title " + title);
				if(title.trim().contains("Canada")){
					System.out.println("Pass Link title "+title);
					oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

				}
				else{
					System.out.println("Fail Link title "+title);
					oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
				}
				oPSelFW.driver.navigate().to(url);
				oPSelFW.driver.navigate().refresh();
				Thread.sleep(5000);
			}else{
				oPSelFW.prolifics("waitForElementPresent", "//h3[text()='"+link+"']", "100");
				oPSelFW.prolifics("clickAndWait", "//h3[text()='"+link+"']", "Click "+link);
				oPSelFW.prolifics("sendReport", "Click "+link, "Successfully clicked "+link, "Pass");
				Thread.sleep(5000);

				String title =  oPSelFW.prolifics("getTitle");
				System.out.println("Title " + title);
				if(title.trim().equalsIgnoreCase(pageTitle1)){
					System.out.println("Pass Link title "+title);
					oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle1, "Pass");

				}
				else{
					System.out.println("Fail Link title "+title);
					oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle1, "Fail");
				}
				oPSelFW.driver.navigate().to(url);
				oPSelFW.driver.navigate().refresh();
				Thread.sleep(5000);

			}
		}
	}
	public void pharmaceutical(String link,String pageTitle, String url) throws InterruptedException
	{
		if(link.contains("Join our team and shape<br />the future of better health.")){
			//oPSelFW.prolifics("waitForElementPresent", "//a[text()='"+link+"']", "100");
			oPSelFW.prolifics("clickAndWait", "//*[@title='Join our team and shape<br />the future of better health.']", "Click "+link);
			Thread.sleep(5000);
			String pageTitle1 =  oPSelFW.driver.getTitle();
			System.out.println("pageTitle1" + pageTitle1);
			System.out.println("pageTitle" + pageTitle);
			if(pageTitle1.trim().contains(pageTitle.trim())){
				System.out.println("Pass------"+pageTitle1);
				oPSelFW.prolifics("sendReport", "Verify Page Title", "Actual Page Title : "+ pageTitle1 +" Expected Page Title : "+pageTitle, "Pass");
			}
			else{
				System.out.println("Fail------"+pageTitle);
				oPSelFW.prolifics("sendReport", "Verify Page Title", "Actual Page Title : "+ pageTitle1 +" Expected Page Title : "+pageTitle, "Fail");
			}
		}else{
			oPSelFW.prolifics("waitForElementPresent", "//a[text()='"+link+"']", "100");
			oPSelFW.prolifics("clickAndWait", "//a[text()='"+link+"']", "Click "+link);
			oPSelFW.prolifics("sendReport", "Click "+link, "Successfully clicked "+link, "Pass");
			Thread.sleep(5000);

			String title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
			if(title.trim().equalsIgnoreCase(pageTitle.trim())){
				System.out.println("Pass Link title "+title);
				oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

			}
			else{
				System.out.println("Fail Link title "+title);
				oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
			}
			oPSelFW.driver.navigate().to(url);
			oPSelFW.driver.navigate().refresh();
			Thread.sleep(5000);
		}
	}
	public void officerLink(String link,String pageTitle, String url) throws InterruptedException{

		oPSelFW.prolifics("waitForElementPresent", "//span[text()='"+link+"']", "100");
		oPSelFW.prolifics("clickAndWait", "//span[text()='"+link+"']", "Click "+link);
		oPSelFW.prolifics("sendReport", "Click "+link, "Successfully clicked "+link, "Pass");
		Thread.sleep(5000);

		String title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
		if(title.trim().equalsIgnoreCase(pageTitle)){
			System.out.println("Pass Link title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

		}
		else{
			System.out.println("Fail Link title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
		}
		oPSelFW.driver.navigate().to(url);
		oPSelFW.driver.navigate().refresh();
		Thread.sleep(5000);
	}
	public void providerLink(String link,String pageTitle, String url) throws InterruptedException{

		oPSelFW.prolifics("waitForElementPresent", "//span[text()='"+link+"']", "100");
		oPSelFW.prolifics("clickAndWait", "//span[text()='"+link+"']", "Click "+link);
		oPSelFW.prolifics("sendReport", "Click "+link, "Successfully clicked "+link, "Pass");
		Thread.sleep(5000);

		String title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
		if(title.trim().equalsIgnoreCase(pageTitle)){
			System.out.println("Pass Link title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

		}
		else{
			System.out.println("Fail Link title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
		}
		oPSelFW.driver.navigate().to(url);
		oPSelFW.driver.navigate().refresh();
		Thread.sleep(5000);
	}
	public void eventsLink(String link,String pageTitle, String url) throws InterruptedException{

		oPSelFW.prolifics("waitForElementPresent", "//*[text()='"+link+"']", "100");
		oPSelFW.prolifics("clickAndWait", "//*[text()='"+link+"']", "Click "+link);
		oPSelFW.prolifics("sendReport", "Click "+link, "Successfully clicked "+link, "Pass");
		Thread.sleep(5000);

		String title = oPSelFW.driver.findElement(By.xpath("//h3[@class='title']")).getText();
		if(title.trim().equalsIgnoreCase(pageTitle.trim())){
			System.out.println("Pass Link title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

		}
		else{
			System.out.println("Fail Link title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
		}
		oPSelFW.driver.navigate().to(url);
		oPSelFW.driver.navigate().refresh();
		Thread.sleep(5000);
	}
	public void anchorLink(String link, String pageTitle) throws InterruptedException{


		String parentWindow = oPSelFW.driver.getWindowHandle();
		oPSelFW.driver.findElement(By.xpath("//span[text()='"+link+"']")).click();
		System.out.println("parentWindow=="+parentWindow);
		Set<String> handles = oPSelFW.driver.getWindowHandles();
		System.out.println("Size=="+handles.size());
		Thread.sleep(5000);
		for(String windowHandle : handles)
		{ System.out.println("inside for"); 
		System.out.println("windowHandle=="+windowHandle);
		if(!windowHandle.equals(parentWindow))
		{ System.out.println("inside if "); 
		oPSelFW.driver.switchTo().window(windowHandle);
		System.out.println("Title "+oPSelFW.driver.getTitle()); 
		String title=oPSelFW.driver.getTitle();
		if(title.trim().equalsIgnoreCase(pageTitle)){
			System.out.println("Pass Link title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

		}
		else{
			System.out.println("Fail Link title "+title);
			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
		}
		Thread.sleep(5000);
		// <!--Perform your operation here for new window-->
		oPSelFW. driver.close(); //closing child window
		oPSelFW.driver.switchTo().window(parentWindow); //cntrl to parent window
		Thread.sleep(5000);
		}
		}

	}
	public void disabledLink()
	{	

		int anchorSize1=oPSelFW.driver.findElements(By.xpath("//*[@class='anchors']//li")).size();

		for (int j=0; j<anchorSize1 ; j++) {

			WebElement ele =oPSelFW.driver.findElements(By.xpath("//*[@class='anchors']//li")).get(j);


			System.out.println(ele.getAttribute("class"));
			if(ele.getAttribute("class").contains("active")){
				System.out.println("element is clickable");
			}else{
				oPSelFW.prolifics("sendReport", "Verify " +ele.getText() +" is disabled", ele.getText() +" disabled", "Pass");
			}
		}	}
	public void anchorLink(){
		int anchorSize=oPSelFW.driver.findElements(By.xpath("//*[@class='anchors']//li[@class='active']")).size();


		for (int i=0; i<anchorSize ; i++) {

			WebElement ele =oPSelFW.driver.findElements(By.xpath("//*[@class='anchors']//li[@class='active']")).get(i);

			WebElement ele1 =oPSelFW.driver.findElements(By.xpath("//*[@class='list']//h4")).get(i);

			if(ele.getText().contains(ele1.getText())){
				oPSelFW.prolifics("sendReport", "Verify whether the product is listed are not", "Product is listed", "Pass");
			}


		}

	}


	public void clickContentPageLinks(String link,String pageTitle, String url){

	}




	public void copyRight(){


		String copyRight =oPSelFW.driver.findElement(By.xpath("//*[@class='footer-disc']//*[contains(text(),'2021 McKesson Corporation')]")).getText();
		System.out.println(copyRight);

		if(copyRight.equalsIgnoreCase("© 2021 McKesson Corporation")){
			System.out.println("Pass------"+copyRight);
			oPSelFW.prolifics("sendReport", "Verify Copyright", "Actual Copyright : 2021 McKesson Corporation, Expected Copyright :  2021 McKesson Corporation", "Pass");
		}
		else{
			System.out.println("Fail------"+copyRight);
			oPSelFW.prolifics("sendReport", "Verify Copyright", "Actual Copyright : 2021 McKesson Corporation, Expected Copyright :  2021 McKesson Corporation", "Fail");
		}


	}
	//Tej Pom


	public void clickLink(String heading, String link, String pageTitle, String URL) throws InterruptedException{

		String parentWindow	= oPSelFW.driver.getWindowHandle();
		if(heading.equalsIgnoreCase("RelayHealth Pharmacy Solutions")||heading.equalsIgnoreCase("McKesson High Volume Solutions")){

			oPSelFW.prolifics("waitForElementPresent", "//h5[text()='"+heading+"']/following-sibling::ul//a[text()='"+link+"']", "100");
			oPSelFW.prolifics("clickAndWait", "//h5[text()='"+heading+"']/following-sibling::ul//a[text()='"+link+"']", "Click "+link);
		}
		if(heading.equalsIgnoreCase("General Inquiries")||heading.equalsIgnoreCase("Pharmacy Business Services")||heading.equalsIgnoreCase("McKesson Printing Services")){
			oPSelFW.prolifics("waitForElementPresent", "//h5[text()='"+heading+"']/following-sibling::li//a[text()='"+link+"']", "100");
			oPSelFW.prolifics("clickAndWait", "//h5[text()='"+heading+"']/following-sibling::li//a[text()='"+link+"']", "Click "+link);
		}
		Thread.sleep(3000);

		Set<String> wHandle = oPSelFW.driver.getWindowHandles();
		for(String cwindow:wHandle){
			if(!cwindow.equals(parentWindow)){
				oPSelFW.driver.switchTo().window(cwindow);
				int eSize = oPSelFW.driver.findElements(By.xpath("//h1[@class='title']")).size();
				if(eSize>0){
					System.out.println("//h1[@class='title']");
					oPSelFW.prolifics("verifyText", "//h1[@class='title']",pageTitle);
				}
				else{
					System.out.println("//h3[@class='title']");
					oPSelFW.prolifics("verifyText", "//h3[@class='title']",pageTitle);	
				}
				oPSelFW.driver.close();
				oPSelFW.driver.switchTo().window(parentWindow);
			}

		}

	}	
	
	public void clickContactLink(String location) throws InterruptedException{

		int size =  oPSelFW.driver.findElements(By.xpath("//h4[text()='"+location+"']/following-sibling::div[1]//li/a")).size();
		System.out.println("size "+size);
		for(int count=1;count<=size;count++){
			System.out.println("count "+count);
			String parentWindow = oPSelFW.driver.getWindowHandle();
			String text	= oPSelFW.driver.findElement(By.xpath("(//h4[text()='"+location+"']/following-sibling::div[1]//li/a)["+count+"]")).getText();
			System.out.println("text "+text);
			text	= removeSpecialCharacter(text);
			oPSelFW.driver.findElement(By.xpath("(//h4[text()='"+location+"']/following-sibling::div[1]//li/a)["+count+"]")).click();
			oPSelFW.prolifics("sendReport", "Click "+text , text+" successfully clicked", "Pass");
			Thread.sleep(5000);
			Set<String> handles = oPSelFW.driver.getWindowHandles();

			for(String windowHandle : handles){ 

				if(!windowHandle.equals(parentWindow)){ 
					System.out.println("inside if "); 
					oPSelFW.driver.switchTo().window(windowHandle);
					oPSelFW. driver.close(); //closing child window
					oPSelFW.driver.switchTo().window(parentWindow); //cntrl to parent window
					Thread.sleep(5000);

				}
			}
		}
	}






	public void pageHelpfulOrNot(String YesorNo, String textIfNoSelected) throws InterruptedException{

		oPSelFW.driver.switchTo().frame(0);
		if(YesorNo.equalsIgnoreCase("Yes")){
			System.out.println("yes "+YesorNo);

			Thread.sleep(7000);
			oPSelFW.prolifics("clickAndWait", "//li[@class='Selection reg']/label", "Click Yes");
			Thread.sleep(2000);
			System.out.println("clicked yes ");
			oPSelFW.prolifics("clickAndWait", "//input[@title='Submit']", "Click Submit");
			Thread.sleep(20000);
			System.out.println("clicked submit ");
		
			String Text = oPSelFW.driver.findElement(By.xpath("//div[@id='EndOfSurvey']")).getText();
			
			System.out.println("Text "+Text);
			if(Text.contains("Your responses will help improve the experience of McKesson.com. Thanks again!")){
				oPSelFW.prolifics("sendReport", "Validate You're all done! Your responses will help improve the experience of McKesson.com. Thanks again! is displayed" , "You're all done! Your responses will help improve the experience of McKesson.com. Thanks again! is displayed successfully", "Pass");
			}
			else{
				oPSelFW.prolifics("sendReport", "Validate You're all done! Your responses will help improve the experience of McKesson.com. Thanks again! is displayed" , "You're all done! Your responses will help improve the experience of McKesson.com. Thanks again! is not displayed", "Fail");
			}
			//oPSelFW.prolifics("verifyText", "//div[@id='EndOfSurvey']","You're all done! Your responses will help improve the experience of McKesson.com. Thanks again!");	
			oPSelFW.driver.navigate().refresh();
		}
		if(YesorNo.equalsIgnoreCase("No")){
			System.out.println("No "+YesorNo);
			oPSelFW.prolifics("clickAndWait", "//li[@class='Selection alt']/label", "Click "+YesorNo);
			Thread.sleep(10000);
			int tbox	= oPSelFW.driver.findElements(By.xpath("//textarea[@id='QR~QID2']")).size();
			if(tbox>0){
				oPSelFW.prolifics("sendReport", "Verify 'What were you trying to accomplish on the site today?' textbox is present" , "'What were you trying to accomplish on the site today?' textbox is present", "Pass");
				oPSelFW.prolifics("typeSpecifiedText", "//textarea[@id='QR~QID2']", textIfNoSelected, "Enter "+textIfNoSelected);
				oPSelFW.prolifics("clickAndWait", "//input[@title='Submit']", "Click Submit");
				Thread.sleep(20000);
				String Text = oPSelFW.driver.findElement(By.xpath("//div[@id='EndOfSurvey']")).getText();
				System.out.println("Text "+Text);
				if(Text.contains("Your responses will help improve the experience of McKesson.com. Thanks again!")){
					oPSelFW.prolifics("sendReport", "Validate You're all done! Your responses will help improve the experience of McKesson.com. Thanks again! is displayed" , "You're all done! Your responses will help improve the experience of McKesson.com. Thanks again! is displayed successfully", "Pass");
				}
				else{
					oPSelFW.prolifics("sendReport", "Validate You're all done! Your responses will help improve the experience of McKesson.com. Thanks again! is displayed" , "You're all done! Your responses will help improve the experience of McKesson.com. Thanks again! is not displayed", "Fail");
				}
				//				oPSelFW.prolifics("verifyText", "//div[@id='EndOfSurvey']","Your responses will help improve the experience of McKesson.com. Thanks again!");	
				oPSelFW.driver.navigate().refresh();
			}else{
				oPSelFW.prolifics("sendReport", "Verify 'What were you trying to accomplish on the site today?' textbox is present" , "'What were you trying to accomplish on the site today?' textbox is not present", "Fail");
			}

		}
		oPSelFW.driver.switchTo().defaultContent();
	}

	public void clickPageContent(String link,String pageTitle, String url) throws InterruptedException{

		oPSelFW.prolifics("waitForElementPresent", "//*[text()='"+link+"']", "100");
		oPSelFW.prolifics("clickAndWait", "//*[text()='"+link+"']", "Click "+link);
		oPSelFW.prolifics("sendReport", "Click "+link, "Successfully clicked "+link, "Pass");
		Thread.sleep(5000);

		int size = oPSelFW.driver.findElements(By.xpath("//h1[@class='title']")).size();
		if(size>0){
			String title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title']")).getText();
			if(title.trim().equalsIgnoreCase(pageTitle.trim())){
				System.out.println("Pass Link title "+title);
				oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

			}
			else{
				System.out.println("Fail Link title "+title);
				oPSelFW.prolifics("sendReportWithOutExit", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
			}
		}
		else{
			String title = oPSelFW.driver.getTitle();
			if(title.contains(pageTitle)){
				oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");
			}
			else{
				oPSelFW.prolifics("sendReportWithOutExit", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
			}
		}

		oPSelFW.driver.navigate().to(url);
		oPSelFW.driver.navigate().refresh();
		Thread.sleep(5000);
	}



	public void clickContentPageLinks(/*String link,String pageTitle, */String url) throws InterruptedException{

		int size = oPSelFW.driver.findElements(By.xpath("//main[@class='feed-container']//article")).size();
		System.out.println("total content "+size);
		if(size>0){

			for(int count=1; count<=2; count++){

				String linkText = oPSelFW.driver.findElement(By.xpath("//main[@class='feed-container']//article["+count+"]//header//a")).getText();
				oPSelFW.prolifics("waitForElementPresent", "//main[@class='feed-container']//article["+count+"]//header//a", "100");
				oPSelFW.prolifics("clickAndWait", "//main[@class='feed-container']//article["+count+"]//header//a", "Click "+linkText);
				Thread.sleep(5000);
				int eSize = oPSelFW.driver.findElements(By.xpath("//h1[@class='title']")).size();
					
				if(eSize>0){
					//System.out.println("//h1[@class='title']");
					oPSelFW.prolifics("verifyText", "//h1[@class='title']",linkText);
				}
				else{
					System.out.println("//h3[@class='title']");
					oPSelFW.prolifics("verifyText", "//h3[@class='title']",linkText);	
				}
				oPSelFW.driver.navigate().to(url);
				
				Thread.sleep(7000);
			}
		}
		else{
			oPSelFW.prolifics("sendReport", "Click content on page", "No content available to click on page", "Pass");

		}
	}


	public void selectFilter(String filterBy, String item, String parameter) throws InterruptedException{


		oPSelFW.prolifics("waitForElementPresent", "//span[@title='"+filterBy+"']", "100");
		oPSelFW.prolifics("clickAndWait", "//span[@title='"+filterBy+"']", "Click "+filterBy);

		System.out.println("clicked filterby "+filterBy);
		Thread.sleep(2000);
		
		oPSelFW.prolifics("waitForElementPresent", "//option[text()='"+item+"']", "100");
		//oPSelFW.prolifics("waitForElementPresent", "//li[text()='"+item+"']", "100");
		oPSelFW.prolifics("clickAndWait", "//li[text()='"+item+"']", "Click "+item);
		System.out.println("clicked item "+item);
		Thread.sleep(7000);
		String cURL	= oPSelFW.driver.getCurrentUrl();
		System.out.println("current url "+cURL);

		if(cURL.trim().contains(parameter)){

			System.out.println("pass "+filterBy);
			oPSelFW.prolifics("sendReport", "Verify Page is refreshed and selected parameter is added in the URL", "Selected parameter : "+filterBy+", Added parameter in URL : "+parameter, "Pass");
		}
		else{
			System.out.println("fail "+item);
			oPSelFW.prolifics("sendReport", "Verify Page is refreshed and selected parameter is added in the URL", "Selected parameter : "+filterBy+", Added parameter in URL : "+parameter, "Fail");
		}
	}

	public void reset(String filterBy) throws InterruptedException{

		oPSelFW.prolifics("waitForElementPresent", "//span[text()='RESET']", "100");
		oPSelFW.prolifics("clickAndWait", "//span[text()='RESET']", "Click Reset");

		Thread.sleep(2000);
		int fsize = oPSelFW.driver.findElements(By.xpath("//span[@title='"+filterBy+"']")).size();
		if(fsize>0){
			oPSelFW.prolifics("sendReport", "Verify "+filterBy+" is reset to default and page is refreshed", "page is refreshed and "+filterBy+" is reset to default successfully", "Pass");
		}
		else{
			oPSelFW.prolifics("sendReport", "Verify "+filterBy+" is reset to default and page is refreshed", "page is refreshed and "+filterBy+" is not reset to default", "Fail");

		}
	}



	public void verifyImage(){

		int size = oPSelFW.driver.findElements(By.xpath("//section[@class='section no-padding login-featured segments']//h3[@class='title']")).size();
		System.out.println("pop sec=="+size);
		if(size>0){
			for(int count=1;count<=size;count++){
				System.out.println("in for =="+count);
				String text	= oPSelFW.driver.findElement(By.xpath("(//section[@class='section no-padding login-featured segments']//h3[@class='title'])["+count+"]")).getText();
				System.out.println("Text==="+text);
				int imgSize	= oPSelFW.driver.findElements(By.xpath("(//section[@class='section no-padding login-featured segments']//h3[@class='title'])["+count+"]/following-sibling::div[@class='image-featured']")).size();
				if(imgSize>0){
					System.out.println("pass-==");
					oPSelFW.prolifics("sendReport", "Verify Image is present for section "+text, "image is present", "Pass");
				}else{
					System.out.println("fail==");
					oPSelFW.prolifics("sendReport", "Verify Image is present for section "+text, "image is not present", "Fail");
				}
			}
		}
		else{
			oPSelFW.prolifics("sendReport", "Verify Image for popular section of page", "No such page is present", "Pass");
		}
	}
	public void subscribeNewsLetter(String email) throws InterruptedException{

		Thread.sleep(3000);

		oPSelFW.driver.switchTo().frame(0);
		oPSelFW.prolifics("waitForElementPresent", "//input[@id='Email']", "100");
		oPSelFW.prolifics("clickAndWait", "//input[@id='Email']", "100");
		oPSelFW.driver.findElement(By.xpath("//input[@id='Email']")).sendKeys(email);
		//oPSelFW.prolifics("typeSpecifiedText", "//input[@id='Email']", email);

		oPSelFW.driver.findElement(By.xpath("//input[@name='consenttoProcess']")).click();
		Thread.sleep(3000);
		oPSelFW.prolifics("waitForElementPresent", "//button[text()='Subscribe']", "100");
		oPSelFW.prolifics("clickAndWait", "//button[text()='Subscribe']", "Click Subscribe");
		Thread.sleep(3000);
		oPSelFW.prolifics("verifyText", "//div[@class='mck-signup-thanks']/p","Thank you! You have been subscribed to our newsletter.");	
		oPSelFW.driver.switchTo().defaultContent();
	}
	public void selectAnyFilter(String filterBy, String item) throws InterruptedException{

		oPSelFW.prolifics("waitForElementPresent", "//span[@title='"+filterBy+"']", "100");
		oPSelFW.prolifics("clickAndWait", "//span[@title='"+filterBy+"']", "Click "+filterBy);

		System.out.println("clicked filterby "+filterBy);
		Thread.sleep(2000);
		oPSelFW.prolifics("waitForElementPresent", "//li[text()='"+item+"']", "100");
		oPSelFW.prolifics("clickAndWait", "//li[text()='"+item+"']", "Click "+item);
		System.out.println("clicked item "+item);
		Thread.sleep(7000);
	}


	public void verifyAllFiltersResult(String month, String author, String segment){

		int aSize = oPSelFW.driver.findElements(By.xpath("//main[@class='feed-container']//article")).size();
		System.out.println("total content "+aSize);
		if(aSize>0){

			String linkText = oPSelFW.driver.findElement(By.xpath("//main[@class='feed-container']//article[1]//header//p")).getText();

			if(linkText.contains(month)&&linkText.contains(author)){
				String tText = oPSelFW.driver.findElement(By.xpath("//div[@id='divTitleText']")).getText();
				if(tText.contains(segment)){
					oPSelFW.prolifics("sendReport", "validate that Results are filtered for selected item", "Results are filtered successfully for selected criteria", "Pass");
				}
				else{
					oPSelFW.prolifics("sendReport", "validate that Results are filtered for selected item", "Results are not filtered for selected criteria", "Fail");
				}
			}
			else{
				oPSelFW.prolifics("sendReport", "validate that Results are filtered for selected item", "Results are not filtered for selected criteria", "Fail");
			}
		}
		else{
			oPSelFW.prolifics("sendReport", "Select any item from all the drop downs and validate that Results are filtered for selected item", "There are no results available for filtered criteria", "Pass"); 
		}
	}


	public void selectFilterForAny(String Type,String filterBy, String item, String parameter) throws InterruptedException{

		if(Type.equalsIgnoreCase("BrowserStack")||Type.equalsIgnoreCase("Mobile")){
			oPSelFW.prolifics("waitForElementPresent", "//span[contains(text(),'Refine Results')]", "100");
			oPSelFW.prolifics("clickAndWait", "//span[contains(text(),'Refine Results')]", "Click Refine Results");
		}


		oPSelFW.prolifics("waitForElementPresent", "//span[@title='"+filterBy+"']", "100");
		oPSelFW.prolifics("clickAndWait", "//span[@title='"+filterBy+"']", "Click "+filterBy);

		System.out.println("clicked filterby "+filterBy);
		Thread.sleep(2000);
		oPSelFW.prolifics("waitForElementPresent", "//li[text()='"+item+"']", "100");
		oPSelFW.prolifics("clickAndWait", "//li[text()='"+item+"']", "Click "+item);
		System.out.println("clicked item "+item);
		Thread.sleep(7000);
		String cURL	= oPSelFW.driver.getCurrentUrl();
		System.out.println("current url "+cURL);

		if(cURL.trim().contains(parameter)){

			System.out.println("pass "+filterBy);
			oPSelFW.prolifics("sendReport", "Verify Page is refreshed and selected parameter is added in the URL", "Selected parameter : "+filterBy+", Added parameter in URL : "+parameter, "Pass");
		}
		else{
			System.out.println("fail "+item);
			oPSelFW.prolifics("sendReport", "Verify Page is refreshed and selected parameter is added in the URL", "Selected parameter : "+filterBy+", Added parameter in URL : "+parameter, "Fail");
		}
	}


	public String removeSpecialCharacter(String str){

		/*System.out.println("spcl char to be removed from "+str);*/
		//String number1 = "Fournitures médicales, produits pharmaceutiques et services de santé | McKesson Canada - McKesson Canada Extranet - Mckesson Canada";
		Pattern pattern = Pattern.compile("[^a-zA-Z 0-9]");
		Matcher matcher = pattern.matcher(str);
		String filterStr = matcher.replaceAll("");
		//	System.out.println("after removing spcl char "+filterStr);
		return filterStr;
	}

	
	public void supplyManager() throws InterruptedException{
		  
		  System.out.println("Inside supply manager");
		  oPSelFW.prolifics("waitForElementPresent", "//a[text()='SUPPLYMANAGER LOGIN']", "100");
		  oPSelFW.prolifics("clickAndWait", "//a[text()='SUPPLYMANAGER LOGIN']", "Click Supply Manager Login button");
		  Thread.sleep(5000);
		  String title = oPSelFW.driver.getTitle();
		  System.out.println("title"+title);
		  
		  if(title.trim().equalsIgnoreCase("McKesson SupplyManager - Please Log In")){
		   oPSelFW.prolifics("sendReport", "Validate Supply Manager Login page title", "Actual page title :"+title+", Expected page title : McKesson SupplyManager - Please Log In", "Pass");
		  }
		  else{
		   oPSelFW.prolifics("sendReport", "Validate Supply Manager Login page title", "Actual page title :"+title+", Expected page title : McKesson SupplyManager - Please Log In", "Fail");
		  }
		  
		  oPSelFW.driver.navigate().back();
		  oPSelFW.driver.navigate().refresh();
		 }
		 
		 
		 public void verifyFieldsOnContactsSalesTab(){
		  
		  
		  int fnSize = oPSelFW.driver.findElements(By.xpath("//input[@id='FirstName']")).size();
		  
		  if(fnSize>0){
		   oPSelFW.prolifics("sendReport", "Verify First Name field", "First Name field is available on page", "Pass");
		  }
		  else{
		   oPSelFW.prolifics("sendReport", "Verify First Name field", "First Name field is not available on page", "Fail");
		  }
		  
		  int lnSize = oPSelFW.driver.findElements(By.xpath("//input[@id='LastName']")).size();
		  
		  if(lnSize>0){
		   oPSelFW.prolifics("sendReport", "Verify Last Name field", "Last Name field is available on page", "Pass");
		  }
		  else{
		   oPSelFW.prolifics("sendReport", "Verify Last Name field", "Last Name field is not available on page", "Fail");
		  }
		  
		  int mSize = oPSelFW.driver.findElements(By.xpath("//input[@id='Email']")).size();
		  
		  if(mSize>0){
		   oPSelFW.prolifics("sendReport", "Verify Email field", "Email field is available on page", "Pass");
		  }
		  else{
		   oPSelFW.prolifics("sendReport", "Verify Email field", "Email field is not available on page", "Fail");
		  }
		  
		  int pSize = oPSelFW.driver.findElements(By.xpath("//input[@id='Phone']")).size();
		  
		  if(pSize>0){
		   oPSelFW.prolifics("sendReport", "Verify Phone field", "Phone field is available on page", "Pass");
		  }
		  else{
		   oPSelFW.prolifics("sendReport", "Verify Phone field", "Phone field is not available on page", "Fail");
		  }
		  
		  int cSize = oPSelFW.driver.findElements(By.xpath("//input[@id='Company']")).size();
		  
		  if(cSize>0){
		   oPSelFW.prolifics("sendReport", "Verify Facility Name field", "Facility Name field is available on page", "Pass");
		  }
		  else{
		   oPSelFW.prolifics("sendReport", "Verify Facility Name field", "Facility Name field is not available on page", "Fail");
		  }
		  
		  int fSize = oPSelFW.driver.findElements(By.xpath("//select[@id='Market_Sub_Segment__c']")).size();
		  
		  if(fSize>0){
		   oPSelFW.prolifics("sendReport", "Verify Facility Type field", "Facility Type field is available on page", "Pass");
		  }
		  else{
		   oPSelFW.prolifics("sendReport", "Verify Facility Type field", "Facility Type field is not available on page", "Fail");
		  }
		  
		  int pcSize = oPSelFW.driver.findElements(By.xpath("//input[@id='PostalCode']")).size();
		  
		  if(pcSize>0){
		   oPSelFW.prolifics("sendReport", "Verify Facility Type field", "Zip Code field is available on page", "Pass");
		  }
		  else{
		   oPSelFW.prolifics("sendReport", "Verify Zip Code field", "Zip Code field is not available on page", "Fail");
		  }
		  
		  int hSize = oPSelFW.driver.findElements(By.xpath("//textarea[@id='Notes__c']")).size();
		  
		  if(hSize>0){
		   oPSelFW.prolifics("sendReport", "Verify How Can We Help You field", "How Can We Help You field is available on page", "Pass");
		  }
		  else{
		   oPSelFW.prolifics("sendReport", "Verify How Can We Help You field", "How Can We Help You field is not available on page", "Fail");
		  }
		 
		  int cbSize = oPSelFW.driver.findElements(By.xpath("//input[@id='mktoCheckbox_5790_0']")).size();
		  
		  if(cbSize>0){
		   oPSelFW.prolifics("sendReport", "Verify I’m an existing McKesson customer field", "I’m an existing McKesson customer field is available on page", "Pass");
		  }
		  else{
		   oPSelFW.prolifics("sendReport", "Verify I’m an existing McKesson customer field", "I’m an existing McKesson customer field is not available on page", "Fail");
		  }
		  
		  int sSize = oPSelFW.driver.findElements(By.xpath("//button[@type='submit']")).size();
		  
		  if(sSize>0){
		   oPSelFW.prolifics("sendReport", "Verify Submit field", "Submit field is available on page", "Pass");
		  }
		  else{
		   oPSelFW.prolifics("sendReport", "Verify Submit field", "Submit field is not available on page", "Fail");
		  }
		 }
		 
		 
		 
		public void validateRequiredField(String fName,String lName,String mail,String phone,String facName,String fType,String pCode,String helpText) throws InterruptedException{
		  
		  oPSelFW.prolifics("waitForElementPresent", "//button[@type='submit']", "100");
		  oPSelFW.prolifics("clickAndWait", "//button[@type='submit']", "Click Submit button");
		  Thread.sleep(2000);
		  oPSelFW.prolifics("verifyText", "//label[text()='First Name']/following-sibling::div//div[@class='mktoErrorMsg']", "This field is required.");
		 System.out.println("Enter f name");
		 Thread.sleep(2000);
		 //oPSelFW.driver.findElement(By.xpath("//input[@id='FirstName']")).sendKeys(fName);  
		  oPSelFW.prolifics("typeSpecifiedText", "//input[@id='FirstName']", fName, "First Name");
		  oPSelFW.prolifics("clickAndWait", "//button[@type='submit']", "Click Submit button");
		  Thread.sleep(2000);
		  oPSelFW.prolifics("verifyText", "//label[text()='Last Name']/following-sibling::div//div[@class='mktoErrorMsg']", "This field is required.");
		 
		  oPSelFW.prolifics("typeSpecifiedText", "//input[@id='LastName']", lName, "Last Name");
		  oPSelFW.prolifics("clickAndWait", "//button[@type='submit']", "Click Submit button");
		  Thread.sleep(2000);
		  String emailText=oPSelFW.driver.findElement(By.xpath("//label[text()='Email']/following-sibling::div//div[@class='mktoErrorMsg']")).getText();
		  System.out.println("emailText "+emailText);
		  oPSelFW.prolifics("verifyText", "//label[text()='Email']/following-sibling::div//div[@class='mktoErrorMsg']", emailText);
		
			 
		  oPSelFW.prolifics("typeSpecifiedText", "//input[@id='Email']", mail, "Email");
		  oPSelFW.prolifics("clickAndWait", "//button[@type='submit']", "Click Submit button");
		  Thread.sleep(2000);
		  String mobileText=oPSelFW.driver.findElement(By.xpath("//label[text()='Phone']/following-sibling::div//div[@class='mktoErrorMsg']")).getText();
		  System.out.println("mobileText "+mobileText);
		  oPSelFW.prolifics("verifyText", "//label[text()='Phone']/following-sibling::div//div[@class='mktoErrorMsg']", mobileText);
		 
		  oPSelFW.prolifics("typeSpecifiedText", "//input[@id='Phone']", phone, "Phone");
		  oPSelFW.prolifics("clickAndWait", "//button[@type='submit']", "Click Submit button");
		  Thread.sleep(2000);
		  oPSelFW.prolifics("verifyText", "//label[text()='Facility Name']/following-sibling::div//div[@class='mktoErrorMsg']", "This field is required.");
		  
		  oPSelFW.prolifics("typeSpecifiedText", "//input[@id='Company']", facName, "Facility Name");
		  oPSelFW.prolifics("clickAndWait", "//button[@type='submit']", "Click Submit button");
		  Thread.sleep(2000);
		  oPSelFW.prolifics("verifyText", "//label[text()='Facility Type']/following-sibling::div//div[@class='mktoErrorMsg']", "This field is required.");
		 
		  Select dDown = new Select(oPSelFW.driver.findElement(By.id("Market_Sub_Segment__c")));
		  dDown.selectByVisibleText(fType);
		  oPSelFW.prolifics("clickAndWait", "//button[@type='submit']", "Click Submit button");
		  Thread.sleep(2000);
		  oPSelFW.prolifics("verifyText", "//label[text()='Zip Code']/following-sibling::div//div[@class='mktoErrorMsg']", "This field is required.");
		  
		  oPSelFW.prolifics("typeSpecifiedText", "//input[@id='PostalCode']", pCode, "Zip Code");
		  oPSelFW.prolifics("clickAndWait", "//button[@type='submit']", "Click Submit button");
		  Thread.sleep(2000);
		  oPSelFW.prolifics("verifyText", "//label[text()='How Can We Help You?']/following-sibling::div//div[@class='mktoErrorMsg']", "This field is required.");
		  
		  oPSelFW.prolifics("typeSpecifiedText", "//textarea[@id='Notes__c']", helpText, "How Can We Help You");
		  oPSelFW.prolifics("clickAndWait", "//button[@type='submit']", "Click Submit button");
		
		  
		  Thread.sleep(100000);
		 }

		public void clickContactSalesOrCustomerSupport(String salesOrSupport) throws InterruptedException{
            Thread.sleep(2000);
            System.out.println("ContactSalesOrCustomerSupport");
            int size = 0;
           oPSelFW.prolifics("waitForElementPresent", "//span[text()='"+salesOrSupport+"']", "100");
            oPSelFW.prolifics("clickAndWait", "//span[text()='"+salesOrSupport+"']", "Click "+salesOrSupport);
         //  oPSelFW.driver.findElement(By.xpath("//span[text()='Customer Support']")).click();
            Thread.sleep(2000);
            if(salesOrSupport.equalsIgnoreCase("Customer Support")){
                            size = oPSelFW.driver.findElements(By.xpath("//div[@class='right-tab-content active']")).size();
            }
            else{
                            size = oPSelFW.driver.findElements(By.xpath("//div[@class='left-tab-content active']")).size();
            }
            
            if(size>0){
                            oPSelFW.prolifics("sendReport", "Click on "+salesOrSupport, salesOrSupport+" tab is opened successfully", "Pass");
            }
            else{
                            oPSelFW.prolifics("sendReport", "Click on "+salesOrSupport, salesOrSupport+" tab is not opened", "Fail");
            }
		}
          
            public void Ourstories(String link,String pageTitle, String url) throws InterruptedException{ 

    			oPSelFW.prolifics("waitForElementPresent", "//span[text()='"+link+"']", "100");
    			oPSelFW.prolifics("clickAndWait", "//span[text()='"+link+"']", "Click "+link);
    			oPSelFW.prolifics("sendReport", "Click "+link, "Successfully clicked "+link, "Pass");
    			Thread.sleep(5000);

    			String title = oPSelFW.driver.findElement(By.xpath("//h1[@class='title white']")).getText();
    			if(title.trim().equalsIgnoreCase(pageTitle.trim())){
    			System.out.println("Pass Link title "+title);
    			oPSelFW.prolifics("sendReport", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Pass");

    			}
    			else{
    			System.out.println("Fail Link title "+title);
    			oPSelFW.prolifics("sendReportWithOutExit", "Verify Title", "Actual Page Title : "+title +" Expected Page Title : "+pageTitle, "Fail");
    			}
    			oPSelFW.driver.navigate().to(url);
    			oPSelFW.driver.navigate().refresh();
    			Thread.sleep(5000); 
            
		}
}
